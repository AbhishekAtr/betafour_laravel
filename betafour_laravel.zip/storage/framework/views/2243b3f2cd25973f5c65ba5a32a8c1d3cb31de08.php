<!-- Header -->

<!-- Header -->




<?php $__env->startSection('main'); ?>
    <section class="news-banner">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="text-white">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('products/' . $product->category)); ?>"
                                    class="text-white"><?php echo e($product->category); ?></a></li>
                            <li class="breadcrumb-item active text-white" aria-current="page"><?php echo e($product->title); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>


    <section class="product-details">
        <div class="container">

            <div class="card">
                <div class="row g-0">
                    <div class="col-md-6 border-end">
                        <div class="d-flex flex-column justify-content-center">
                            <div class="main_image">
                                <img src="/uploads/<?php echo e($product->image); ?>" id="main_product_image" width="350" />
                            </div>
                            <div class="thumbnail_images">
                                <ul id="thumbnail">
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 right-side">
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="text-danger"><?php echo e($product->title); ?></h3>
                            </div>
                            <?php echo $product->description; ?>

                        </div>

                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>

    <!-- footer  -->
<?php $__env->stopSection(); ?>

<a href="https://wa.me/8826660388" class="whatsapp_float" target="_blank" rel="noopener noreferrer">
    <i class="fa fa-whatsapp whatsapp-icon"></i>
</a>

<?php echo $__env->make('frontend.include.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\betafour\resources\views/frontend/productdetails.blade.php ENDPATH**/ ?>