 

 <?php $__env->startSection('main'); ?>
     <div class="row">
         <div class="col-md-12 py-4">
             <div class="card bg-light text-center mt-5">
                 <div class="card-body">
                     <h1>Welocme to Dashboard</h1>
                 </div>
             </div>
         </div>
     </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\betafour_laravel\resources\views/backend/dasboard.blade.php ENDPATH**/ ?>