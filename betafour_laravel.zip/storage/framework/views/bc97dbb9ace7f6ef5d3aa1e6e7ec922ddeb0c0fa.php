<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
</script>
<script src="<?php echo e(url('backend/js/main.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script language="JavaScript">
    javascript: window.history.forward(1);
</script>
<script>
    $(document).ready(function() {
        $("#description").summernote();
        $("#description1").summernote();
        $('.dropdown-toggle').dropdown();
    });
    $(function() {
    $('#sidebar-nav a').click(function() {
        $('#sidebar-nav a.active').removeClass('active');
        $(this).addClass('active');
    });
});
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\betafour\resources\views/backend/include/js-url.blade.php ENDPATH**/ ?>