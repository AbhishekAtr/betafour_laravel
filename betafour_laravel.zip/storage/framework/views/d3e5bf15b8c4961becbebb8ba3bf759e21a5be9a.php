
 <script src="<?php echo e(url('frontend/js/jquery-3.3.1.min.js')); ?>"></script>
  <!-- <script src="<?php echo e(url('frontend/js/popper.min.js')); ?>"></script> -->
  <script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('frontend/js/jquery.sticky.js')); ?>')}}"></script>
  <script src="<?php echo e(url('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(url('frontend/js/main.js')); ?>"></script>
  <script src="<?php echo e(url('frontend/css/slick.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\betafour_laravel\resources\views/frontend/include/js-url.blade.php ENDPATH**/ ?>