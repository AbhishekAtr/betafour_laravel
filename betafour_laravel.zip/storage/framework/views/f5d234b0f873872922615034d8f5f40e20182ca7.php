<!-- CSS-url -->
<?php echo $__env->make('frontend.include.css-url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header Start -->

<div class="site-mobile-menu site-navbar-target">
  <div class="site-mobile-menu-header">
    <div class="site-mobile-menu-close mt-3">
      <span class="icon-close2 js-menu-toggle"></span>
    </div>
  </div>
  <div class="site-mobile-menu-body"></div>
</div>



<header class="site-navbar site-navbar-target bg-white fixed-top text-uppercase" role="banner">

  <div class="container">
    <div class="row align-items-center position-relative">

      <div class="col-lg-4">
        <nav class="site-navigation ml-auto" role="navigation">
          <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Products</a>
             
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a class="dropdown-item" href="<?php echo e(url('products/'.$cat->title)); ?>"><?php echo e($cat->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </li>
            <li><a href="<?php echo e(url('/newrelease')); ?>" class="nav-link <?php echo e(request()->is('new-release')? 'active': ''); ?>">New Release</a></li>
            <li><a href="<?php echo e(url('/catalogue')); ?>" class="nav-link <?php echo e(request()->is('catalogue')? 'active': ''); ?>">Catalogue</a></li>
          </ul>
         
        </nav>
      </div>
      <div class="col-lg-4 text-center">
        <div class="site-logo">
          <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(url('frontend/images/logo/logo1.png')); ?>" alt="">
          </a>
        </div>


        <div class="ml-auto toggle-button d-inline-block d-lg-none">
          <a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black">
            <span class="icon-menu h3 text-black"></span>
          </a>
        </div>
      </div>
      <div class="col-lg-4">
        <nav class="site-navigation" role="navigation" style="padding-left: 25px;">
          <ul class="site-menu main-menu js-clone-nav  d-none d-lg-block ">
            <li class="<?php echo e(request()->is('news')? 'active': ''); ?>"><a href="<?php echo e(url('/news')); ?>" class="nav-link">News & Events</a></li>
            <li class="<?php echo e(request()->is('about')? 'active': ''); ?>"><a href="<?php echo e(url('/about')); ?>" class="nav-link">About</a></li>
            <li class="<?php echo e(request()->is('contact')? 'active': ''); ?>"><a href="<?php echo e(url('/contact')); ?>" class="nav-link">Contact</a></li>
          </ul>
        </nav>
      </div>


    </div>
  </div>

</header>

<!-- end --><?php /**PATH C:\xampp\htdocs\betafour_laravel\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>