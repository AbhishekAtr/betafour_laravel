@include('frontend.include.header')
@yield('main')
@include('frontend.include.footer')