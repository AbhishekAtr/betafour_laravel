 @extends('backend.include.sidebar')

 @section('main')
     <div class="row">
         <div class="col-md-12 py-4">
             <div class="card bg-light text-center mt-5">
                 <div class="card-body">
                     <h1>Welocme to Dashboard</h1>
                 </div>
             </div>
         </div>
     </div>
 @endsection
