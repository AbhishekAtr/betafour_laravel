<?php
use App\Models\Categories;
function getCat()
{
    
}
?>